# Displaying Data in a List

## Completed Project

Explore the completed project for [Displaying Data in a List](https://developer.apple.com/tutorials/app-dev-training/displaying-data-in-a-list).